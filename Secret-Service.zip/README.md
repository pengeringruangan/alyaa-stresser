# ZER0BOT V2.1 🐐
> ZER0 BOT The discord API turns your discord chat channel into a C&C server!
> You can add or remove methods, tools,...

# Store: https://condi.billgang.store/

# Installation:
```sh
1. Install NodeJS 12.x
2. Install Screen: apt-get install screen -y
3. Use your bot token generated at Discord Devoloper website
4. Paste the bot token on line 286 in the bot.js file
5. Copy the ROOM ID where the attack command is written and change the ROOM ID at line 3 of the file ayarlar.json
6. Customize attack commands in 2 folders attack_layer7 and attack_layer4
7. Run the command to start the bot by typing node bot.js
8. Let's have fun

NOTE: easy install pls dont say me how to install
```

# Log
```sh
- SMALL UPDATE ANTI SKID
- UPDATE METHODS COMMAND
- NEW GEOIP FUNCTION
```

# Credits
```sh
zxcr9999
rcong
(Thank for using <3)
```

# TOS:
```sh
I do not accept any responsibility for your use of the source code for any purpose
Remember: Purpose born to study
```

# NOTE:
```sh
LATEST RELEASE AND WITHOUT ANY ERROR
```

# CONTACT:
```sh
Telegram: @learneverything9
```
